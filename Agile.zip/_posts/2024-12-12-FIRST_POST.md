---
layout: post
title: "Welcome to Agile Blog"
date: 2024-12-13
categories: agile
---
This is our first post, sharing insights on Agile methodologies.
